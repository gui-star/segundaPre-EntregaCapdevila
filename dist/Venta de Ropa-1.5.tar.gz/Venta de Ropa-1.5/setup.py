from setuptools import setup

setup(
    name="Venta de Ropa",
    version="1.5",
    description="Impresion de factura",
    author="Guillermo Capdevila",
    author_email="guille@gmail.com",
    packages=["paquete1"]
)
